# budgie-remix welcome screen
============================
### Installation
    $ sudo apt install python3-simplejson
      [password]
    $ git clone https://github.com/budgie-remix/budgie-remix-welcome
### Testing

    $ cd budgie-remix-welcome 
    $ ./budgie-remix-welcome
