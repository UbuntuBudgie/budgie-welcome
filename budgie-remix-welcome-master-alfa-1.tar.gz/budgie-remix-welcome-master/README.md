
budgie-remix-welcome
================

budgie-remix welcome screen


To install:

sudo apt install python3-simplejson
git clone https://github.com/budgie-remix/budgie-remix-welcome

To test:

cd budgie-remix-welcome
./budgie-remix-welcome

